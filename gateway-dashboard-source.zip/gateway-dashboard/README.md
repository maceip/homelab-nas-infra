# Gateway instrument cluster

A fluid, single-row reconstruction of the supplied LCD instrument panel, using Wimbledon green material, molded square grain, recessed black glass, beveled console edges, and warm amber illumination. The panel fills the available page width with a small outer inset, without a maximum-width cap. There is no page heading, tab switcher, refresh button, or refresh/status caption outside the instruments.

The four left instruments show disk capacity, monthly token use, CPU temperature, and network bandwidth. The center has three-digit RAM usage and CPU utilization. LOCAL MODEL is a placeholder model name rendered on separate mechanical letter drums: each wheel has its own shaded surface, slightly different registration, neighboring letters, and a staggered startup roll. A changed model-name prop rolls the new text into place.

The lower strips each have six square lamp positions. RUN follows the center RUN/HOLD control, NET follows network activity, and API, DB, CACHE, and QUEUE have sample service states. The physical knob pauses and resumes all instrument motion. An enlarged invisible touch area keeps the small knob usable on phones.

## Motion

`lib/instrument-motion.ts` separates the replaceable sample feed from the display sequence. On loading, a 3.4-second startup self-test fills all four left meters and the right arc, lights every segment of the numeric displays, checks the service lamps, empties the gauges, and settles into the readings. The right arc has 42 narrow amber cells over a continuous muted olive ribbon. The small network gauge fills beneath its four diagonal rail dashes instead of behaving as a binary light. Dark scoring remains visible through the glow.

After the test, a repeatable activity cycle drives the token rate, CPU, RAM, temperature, and bandwidth displays. Disk use stays steady; monthly use accumulates. Both the numeric values and their illuminated bars come from the same frame. RUN/HOLD freezes and resumes the clock. Reduced-motion mode skips the startup sweeps and wheel animation and updates readings at a lower rate. Backgrounded tabs do not accumulate a large animation jump.

This remains a design preview powered by sample readings, not a connection to the Raspberry Pi or a live model. No sample captions are shown on the panel, as requested. Replace `sampleReadings()` with the actual telemetry source before treating it as a system monitor. The 9/12/15 marks on the second left instrument reproduce the reference; its metric label and numeric value provide the current units.

All instruments use HTML, CSS, and SVG. The source photo and videos are references, not flattened UI assets. The cluster retains its compact proportions on phones rather than stacking its three main windows.
