"use client";
import { useEffect, useRef, useState, type CSSProperties } from "react";
import { ArrowRight, Cpu, Database, HardDrive, Network, Pause, Play, Sun, Thermometer, Zap } from "lucide-react";
import { instrumentFrame, startupDuration, type InstrumentFrame } from "@/lib/instrument-motion";
const digitMap:Record<string,number[]>={"0":[0,1,2,3,4,5],"1":[1,2],"2":[0,1,6,4,3],"3":[0,1,6,2,3],"4":[5,6,1,2],"5":[0,5,6,2,3],"6":[0,5,6,4,2,3],"7":[0,1,2],"8":[0,1,2,3,4,5,6],"9":[0,1,2,3,5,6],"—":[6]};
const segments=["11,2 43,2 50,9 42,16 13,16 6,9","43,16 51,9 51,42 44,49 37,42 37,22","44,51 51,58 51,87 44,94 37,87 37,58","13,84 42,84 49,91 42,98 11,98 4,91","3,58 10,51 17,58 17,84 10,91 3,84","3,9 10,16 17,22 17,42 10,49 3,42","13,43 41,43 48,50 41,57 13,57 6,50"];
function Digits({value,className=""}:{value:string;className?:string}){
  let width=0;
  const characters=value.split("").map((character,index)=>{const x=width;width+=character==="."?16:58;return character==="."?<rect key={index} x={x+2} y="85" width="12" height="12" rx="1" className="digit-on"/>:<g key={index} transform={`translate(${x},0)`}>{segments.map((points,i)=><polygon key={i} points={points} className={digitMap[character]?.includes(i)?"digit-on":"digit-off"}/>)}</g>;});
  return <svg className={`digits ${className}`} viewBox={`0 0 ${width} 100`} style={{width:`${width/100}em`}} aria-hidden="true">{characters}</svg>;
}
type MeterKind="disk"|"monthly"|"temperature"|"network"|"io";
type MeterBlock={path:string;tone?:"green"|"red";scores?:[number,number]};
function MeterGraphic({kind,value,max}:{kind:MeterKind;value:number;max:number}){
  const id=`meter-${kind}`;
  const end=kind==="disk"?191:kind==="monthly"||kind==="io"?183:244;
  const ratio=Math.max(0,Math.min(1,value/max));
  const fillWidth=ratio===0?0:3+(end-3)*ratio;
  let blocks:MeterBlock[],rails:MeterBlock[];
  if(kind==="disk"){
    blocks=[
      {path:"M3 53 Q20 28 47 22 L47 42 Q32 43 25 53Z",scores:[3,47]},
      ...[51,99,147].map(x=>({path:`M${x} 22h44v22h-44Z`,scores:[x,x+44] as [number,number]})),
    ];
    rails=[51,99,147,195].map(x=>({path:`M${x} 12h44v5h-44Z`}));
  }else if(kind==="temperature"){
    blocks=[
      {path:"M3 43 Q17 24 36 17 L36 45 Q18 50 3 53Z",tone:"green",scores:[3,36]},
      ...[40,80,120,160].map(x=>({path:`M${x} 10h35v35h-35Z`,scores:[x,x+35] as [number,number]})),
      {path:"M200 10 Q223 10 237 0 L244 0 L244 27 Q225 45 200 45Z",tone:"red"},
    ];
    rails=[];
  }else if(kind==="network"){
    blocks=[{path:"M3 53H22V50L244 17V66H3Z"}];
    // Four separate, collinear strokes: the original fuel gauge's fine rising rail.
    rails=Array.from({length:4},(_,i)=>{const x=3+i*61,y=44-i*9;return {path:`M${x} ${y}l56 -8.262v5l-56 8.262Z`};});
  }else{
    blocks=[[3,27],[34,28],[67,56],[128,55]].map(([x,width])=>({path:`M${x} 22h${width}v21h-${width}Z`,scores:[x,x+width] as [number,number]}));
    rails=[{path:"M3 11h59v5H3Z",tone:"red"},{path:"M67 11h56v5H67Z"}];
  }
  const shapes=blocks.map(({path,tone},i)=><path key={i} d={path} className={`meter-block lcd-${tone??"amber"}`}/>);
  return <svg className="mini-track" viewBox="0 0 250 70" preserveAspectRatio="xMinYMid meet" aria-hidden="true">
    <defs>
      <clipPath id={`${id}-profile`}>{blocks.map(({path},i)=><path key={i} d={path}/>)}</clipPath>
      <clipPath id={`${id}-lit`}><rect width={fillWidth} height="70"/></clipPath>
    </defs>
    <g className="meter-body">{shapes}</g>
    <g className="meter-illumination"><g className="meter-lit" clipPath={`url(#${id}-lit)`}>{shapes}</g></g>
    <g className="meter-scoring" clipPath={`url(#${id}-profile)`}>
      {blocks.flatMap(({scores},block)=>scores?Array.from({length:4},(_,tick)=>{const x=scores[0]+(scores[1]-scores[0])*(tick+1)/5;return <path key={`${block}-${tick}`} d={`M${x} 0v70`}/>;}):[])}
      {kind==="network"&&Array.from({length:24},(_,i)=><path key={`network-${i}`} d={`M${3+(i+1)*10} 0v70`}/>)}
    </g>
    {rails.map(({path,tone},i)=><path key={i} d={path} className={`meter-rail lcd-${tone??"amber"}`}/>)}
    {kind==="temperature"&&<path className="meter-channel" d="M1 40 Q16 22 36 18 L200 18 Q226 18 245 1"/>}
    {(kind==="monthly"||kind==="io")&&<g className="meter-scale">{[["9",34],["12",122],["15",222]].map(([text,x])=><text key={text} x={x} y="65" textAnchor="middle">{text}</text>)}</g>}
  </svg>;
}
function MiniMeter({kind,label,value,max,unit}:{kind:MeterKind;label:string;value:number;max:number;unit:string}){
  const Icon=kind==="disk"?HardDrive:kind==="monthly"?Zap:kind==="temperature"?Thermometer:kind==="io"?Database:Network;
  return <article className={`mini-meter ${kind}`} aria-label={`${label}: ${value} ${unit}`}>
    <div className="meter-icon" aria-hidden="true"><Icon strokeWidth={1.9}/></div>
    <div className="mini-body"><div className="meter-label"><h2>{label}</h2><span>{value}<small>{unit}</small></span></div>
      <MeterGraphic kind={kind} value={value} max={max}/>
    </div>
  </article>;
}
function RevMeter({value,system}:{value:number;system:boolean}){
  // The resting LCD is a continuous olive ribbon. Only illuminated cells show scoring.
  const max=system?100:70,count=42,start=46,end=460,step=(end-start)/count;
  const marks=system?
    [{value:0,x:73,y:439},{value:20,x:160,y:367},{value:40,x:247,y:269},{value:60,x:321,y:184},{value:80,x:371,y:180},{value:100,x:454,y:230}]:
    [{value:5,x:73,y:439},{value:10,x:103,y:421},{value:20,x:161,y:367},{value:30,x:219,y:308},{value:40,x:279,y:226},{value:50,x:338,y:166},{value:60,x:393,y:191},{value:70,x:454,y:230}];
  const anchors=[{value:0,x:start},...marks.filter(mark=>mark.value>0),{value:max,x:end}];
  const bounded=Math.max(0,Math.min(max,value));
  const upper=anchors.findIndex(mark=>mark.value>=bounded);
  const low=anchors[Math.max(0,upper-1)],high=anchors[Math.max(0,upper)];
  const fillX=bounded>=max?end:high.value===low.value?low.x:low.x+(high.x-low.x)*(bounded-low.value)/(high.value-low.value);
  const lit=Math.max(0,Math.min(count,Math.round((fillX-start)/step)));
  const id=`rising-band-${system?"cpu":"tokens"}`;
  const path="M46 460 C116 454 180 391 247 304 C281 261 311 216 329 190 C340 174 357 174 371 193 C394 223 419 240 460 246 L460 294 C421 288 394 276 368 253 C356 240 343 243 332 257 C302 295 274 334 239 373 C174 447 106 498 46 507Z";
  return <article className="rev-window glass" aria-label={`${system?"CPU utilization":"Tokens per second"}: ${value}${system?" percent":" tokens per second"}`}>
    <svg className="rev-display" viewBox="20 100 454 425" preserveAspectRatio="xMidYMid meet" aria-hidden="true">
      <defs><clipPath id={id}><path d={path}/></clipPath></defs>
      <path d={path} className="rev-resting-band"/>
      <g className="rev-illumination"><g clipPath={`url(#${id})`}>{Array.from({length:count},(_,i)=><rect key={i} x={start+i*step} y="170" width={step-.85} height="340" className={`rev-cell ${i<lit?"is-lit":""}`}/>)}</g></g>
      <g className="rev-scoring" clipPath={`url(#${id})`}>{Array.from({length:Math.max(0,lit-1)},(_,i)=><path key={i} d={`M${start+(i+1)*step-.45} 170v340`}/>)}</g>
      {marks.map(({value:mark,x,y})=>{
        const digits=String(mark),scale=.38,labelX=Math.min(x,mark===100?430:438);
        return <g key={mark} className="rev-scale-mark">
          <g className="rev-scale-numerals" transform={`translate(${labelX-digits.length*58*scale/2+4} ${y-(mark===30&&!system?30:21)-38}) scale(${scale}) skewX(-7)`}>
            {digits.split("").map((digit,index)=><g key={index} transform={`translate(${index*58} 0)`}>{digitMap[digit].map(segment=><polygon key={segment} points={segments[segment]}/>)}</g>)}
          </g>
          <circle cx={x} cy={y} r="4.4"/>
        </g>;
      })}
      <g className="rev-legend"><text x="74" y="151">{system?"CPU LOAD":"TOKENS"}</text><text className="rev-legend-unit" x="74" y="176">{system?"PERCENT":"PER SECOND"}</text></g>
    </svg>
    <h2 className="sr-only">{system?"CPU load":"Tokens per second"}</h2>
    <div className="rev-value"><Digits value={system?String(value):value.toFixed(1)}/><span>{system?"% UTILIZATION":"TOK / SEC"}</span></div>
  </article>;
}
function ServiceStrip({side,running,network,testing}:{side:"left"|"right";running:boolean;network:number;testing:boolean}){
  const entries=side==="left"?
    [{name:"RUN",on:running,Icon:Sun,tone:"run-lamp"},{name:"API",on:true,Icon:Network,tone:"api-lamp"},{name:"DB",on:true,Icon:Database,tone:""}]:
    [{name:"NET",on:network>0,Icon:ArrowRight,tone:""},{name:"CACHE",on:false,Icon:Zap,tone:"warning-lamp"},{name:"QUEUE",on:false,Icon:Cpu,tone:"warning-lamp"}];
  return <div className={`service-strip ${side}`} aria-label="Service indicators">{entries.map(({name,on,Icon,tone})=><div key={name} className={`annunciator ${on||testing?"online":"standby"} ${tone}`} aria-label={`${name}: ${testing?"lamp test":on?"active":"standby"}`}><Icon aria-hidden="true"/><span>{name}</span></div>)}{Array.from({length:3},(_,i)=><div key={i} className="blank-lamp" aria-hidden="true"/>)}</div>;
}
function Odometer({value}:{value:string}){
  const alphabet=" ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789.-";
  return <div className="model-odometer" aria-label={value} key={value}>
    {value.toUpperCase().split("").map((character,index)=>{
      const at=Math.max(0,alphabet.indexOf(character));
      return <span key={index} className={`odometer-wheel ${character===" "?"word-gap":""}`} aria-hidden="true" style={{"--drum-offset":`${[-.06,.035,-.025,.07,-.04][index%5]}cqw`,"--roll-delay":`${index*.045}s`,"--roll-duration":`${1.2+(index%4)*.13}s`} as CSSProperties}>
        <span className="drum-strip">{Array.from({length:9},(_,row)=><span key={row} className={row===4?"drum-current":"drum-neighbor"}>{alphabet[(at+row-4+alphabet.length)%alphabet.length]||"\u00a0"}</span>)}</span>
      </span>;
    })}
  </div>;
}
function Cluster({frame,running,onToggle}:{frame:InstrumentFrame;running:boolean;onToggle:()=>void}){
  const {readings,phase}=frame,testing=phase==="lamp-test";
  return <section className="instrument-cluster" data-phase={phase} data-running={running} aria-label="Performance instrument cluster" aria-busy={phase!=="running"}>
    <div className="instrument-row">
      <div className="aux-window glass">
        <MiniMeter kind="disk" label="DISK" value={readings.disk} max={100} unit="%"/>
        <MiniMeter kind="monthly" label="TOK / MONTH" value={+readings.monthly.toFixed(2)} max={40} unit="B"/>
        <MiniMeter kind="temperature" label="CPU TEMP" value={readings.temperature} max={100} unit="°C"/>
        <MiniMeter kind="network" label="NETWORK" value={readings.network} max={10} unit="kB/s"/>
      </div>
      <div className="centre-console">
        <article className="ram-window glass" aria-label={testing?"RAM display self-test":`RAM usage: ${readings.memory} percent`}><h2>RAM USAGE</h2><div className="ram-value"><Digits value={testing?"888":String(readings.memory).padStart(3,"0")}/><span>%</span></div></article>
        <div className="console-signature" aria-hidden="true">GATEWAY ELECTRONICS</div>
        <div className="odometer-row"><article className="model-console" aria-label="Model name"><h2>MODEL</h2><Odometer value="LOCAL MODEL"/></article><article className="small-console" aria-label={`CPU utilization: ${readings.cpu} percent`}><h2>CPU</h2><div className="small-display"><Digits value={testing?"888":String(readings.cpu).padStart(2,"0")}/><span>%</span></div></article></div>
      </div>
      <RevMeter value={readings.tokens} system={false}/>
    </div>
    <div className="lower-console"><ServiceStrip side="left" running={running} network={readings.network} testing={testing}/><div className="mode-knob"><span className={running?"selected":""}>RUN</span><button className={`knob ${running?"running":""}`} onClick={onToggle} aria-label={running?"Pause instruments":"Resume instruments"}>{running?<Pause aria-hidden="true"/>:<Play aria-hidden="true"/>}</button><span className={!running?"selected":""}>HOLD</span></div><ServiceStrip side="right" running={running} network={readings.network} testing={testing}/></div>
  </section>;
}
export default function Home(){
  const [frame,setFrame]=useState<InstrumentFrame>(()=>instrumentFrame(0));
  const [running,setRunning]=useState(true);
  const elapsed=useRef(0);
  useEffect(()=>{
    if(!running)return;
    const preference=window.matchMedia("(prefers-reduced-motion: reduce)");
    const syncPreference=()=>{if(preference.matches)elapsed.current=Math.max(elapsed.current,startupDuration);setFrame(instrumentFrame(elapsed.current,preference.matches));};
    syncPreference();
    preference.addEventListener("change",syncPreference);
    let request=0,last=performance.now(),paint=0;
    const tick=(now:number)=>{
      // Returning to a backgrounded tab resumes the sequence without a time jump.
      elapsed.current+=Math.min((now-last)/1000,.1);last=now;
      if(now-paint>=(preference.matches?500:33)){paint=now;setFrame(instrumentFrame(elapsed.current,preference.matches));}
      request=requestAnimationFrame(tick);
    };
    request=requestAnimationFrame(tick);
    return()=>{cancelAnimationFrame(request);preference.removeEventListener("change",syncPreference);};
  },[running]);
  return <main className="dashboard"><Cluster frame={frame} running={running} onToggle={()=>setRunning(s=>!s)}/></main>;
}
