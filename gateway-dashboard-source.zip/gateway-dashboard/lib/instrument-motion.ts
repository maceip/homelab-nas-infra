export type Readings = {
  disk: number;
  tokens: number;
  monthly: number;
  cpu: number;
  memory: number;
  temperature: number;
  network: number;
};
export type InstrumentPhase = "power-on" | "sweep-up" | "lamp-test" | "sweep-down" | "settling" | "running";
export type InstrumentFrame = { readings: Readings; phase: InstrumentPhase };

export const startupDuration = 3.4;
export const initial: Readings = { disk: 5, tokens: 35.7, monthly: 28, cpu: 32, memory: 16, temperature: 45.8, network: 1.6 };
const maximum: Readings = { disk: 100, tokens: 70, monthly: 40, cpu: 100, memory: 100, temperature: 100, network: 10 };
const round = (n: number) => Math.round(n * 10) / 10;
const clamp = (n: number, min: number, max: number) => Math.max(min, Math.min(max, n));
const ease = (n: number) => n * n * (3 - 2 * n);

function scale(readings: Readings, progress: number): Readings {
  const p = clamp(progress, 0, 1);
  return {
    disk: round(readings.disk * p), tokens: round(readings.tokens * p), monthly: round(readings.monthly * p),
    cpu: Math.round(readings.cpu * p), memory: Math.round(readings.memory * p),
    temperature: round(readings.temperature * p), network: round(readings.network * p),
  };
}

// A replaceable sample feed: the instrument animation never pretends to query a server.
// Storage stays stable, monthly usage accumulates, and activity follows a repeatable load cycle.
export function sampleReadings(seconds: number): Readings {
  const t = Math.max(0, seconds);
  const cycle = [[0, 35.7], [1.8, 48], [3, 50], [4.2, 12], [5.8, 9], [8, 59], [9, 62], [10.2, 22], [12, 35.7]];
  const clock = t % 12;
  const next = cycle.findIndex(([at]) => at > clock);
  const [fromTime, fromValue] = cycle[Math.max(0, next - 1)];
  const [toTime, toValue] = cycle[next];
  const tokens = round(fromValue + (toValue - fromValue) * ease((clock - fromTime) / (toTime - fromTime)));
  return {
    disk: initial.disk,
    monthly: Math.min(40, Math.round((initial.monthly + t * .000003) * 1000) / 1000),
    tokens,
    cpu: Math.round(clamp(initial.cpu + (tokens - initial.tokens) * 1.15, 0, 100)),
    memory: Math.round(initial.memory + 2 * Math.sin(t / 4) + Math.max(0, tokens - initial.tokens) / 15),
    temperature: round(initial.temperature + 1.6 * Math.sin(t / 6)),
    network: round(clamp(initial.network + (tokens - initial.tokens) * .12 + .3 * Math.sin(t * 1.4), 0, 10)),
  };
}

export function instrumentFrame(seconds: number, reducedMotion = false): InstrumentFrame {
  const t = Math.max(0, seconds);
  if (reducedMotion) return { readings: sampleReadings(Math.max(0, t - startupDuration)), phase: "running" };
  if (t < .2) return { readings: scale(maximum, 0), phase: "power-on" };
  if (t < 1.45) return { readings: scale(maximum, (t - .2) / 1.25), phase: "sweep-up" };
  if (t < 1.8) return { readings: maximum, phase: "lamp-test" };
  if (t < 2.5) return { readings: scale(maximum, 1 - (t - 1.8) / .7), phase: "sweep-down" };
  if (t < startupDuration) return { readings: scale(initial, ease((t - 2.5) / .9)), phase: "settling" };
  return { readings: sampleReadings(t - startupDuration), phase: "running" };
}
